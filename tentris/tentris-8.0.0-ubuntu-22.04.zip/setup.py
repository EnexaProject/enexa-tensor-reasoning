#!/usr/bin/env python3

from setuptools import setup

setup(name="tentris",
      version="8.0.0",
      packages=["tentris"],
      package_dir={"tentris": "tentris"},
      package_data={"tentris": ["*.so"]},
      install_requires=["numpy"])
