import os
import sys

cur_file_dir = os.path.dirname(os.path.realpath(__file__))

# add current file directory so that tentris_sys.*.so is found by python
sys.path.append(cur_file_dir)

# load all symbols of tentris into top level module
from .tentris import *
