import tentris_sys

import enum
import functools
import typing

import numpy


@functools.total_ordering
class IRI:
    __slots__ = "_inner",

    @classmethod
    def _from_raw(cls, inner: tentris_sys.rdf4cpp_node):
        self = cls.__new__(cls)
        self._inner = inner
        return self

    def __init__(self, iri: str):
        """Constructs a new IRI from its string representation"""
        self._inner = tentris_sys.rdf4cpp_make_iri(iri)

    def identifier(self) -> str:
        """Returns the IRI as string"""
        return tentris_sys.rdf4cpp_iri_identifier(self._inner)

    def __str__(self):
        """Returns the n-format representation of this IRI"""
        return tentris_sys.rdf4cpp_serialize(self._inner)

    def __repr__(self):
        return f"IRI._from_raw(tentris_sys.rdf4cpp_node({int(self._inner)}))"

    def __int__(self) -> int:
        """
        Returns internal ID of the IRI.
        IDs of IRIs constructed via __init__() and IRIs from TripleStores might not match.
        """
        return int(self._inner)

    def __hash__(self):
        return int(self)

    def __eq__(self, other: "Node") -> bool:
        """node comparison as defined by SPARQL"""
        return tentris_sys.rdf4cpp_term_cmp(self._inner, other._inner) == 0

    def __lt__(self, other: "Node") -> bool:
        """node comparison as defined by SPARQL"""
        return tentris_sys.rdf4cpp_term_cmp(self._inner, other._inner) < 0


@functools.total_ordering
class Literal:
    __slots__ = "_inner",

    @classmethod
    def _from_raw(cls, inner: tentris_sys.rdf4cpp_node):
        self = cls.__new__(cls)
        self._inner = inner
        return self

    def __init__(self, lexical: str, *, datatype: typing.Optional[IRI] = None, language: typing.Optional[str] = None):
        """
        Constructs a Literal from the given parameters

        Example:: python
            import tentris
            ls = tentris.Literal("spherical cow")  # "spherical cow"
            ll = tentris.Literal("spherical cow", language="en")  # "spherical cow"@en
            ld = tentris.Literal("5", datatype=XSD.int)  # "5"^^xsd:int
            # invalid = tentris.Literal("5", datatype=XSD.int, language="en")  # raises exception

        :param lexical: the lexical form of the Literal
        :param datatype: optionally, the datatype of the literal
        :param language: optionally, the language of the datatype
        :raises: an exception if the literal is not valid
        """
        self._inner = tentris_sys.rdf4cpp_make_literal(lexical, datatype._inner if datatype is not None else None, language)

    def lexical_form(self) -> str:
        """Returns the lexical form of this Literal"""
        return tentris_sys.rdf4cpp_literal_lexical_form(self._inner)

    def datatype(self) -> IRI:
        """Returns the datatype of this Literal"""
        return IRI._from_raw(tentris_sys.rdf4cpp_literal_datatype(self._inner))

    def language(self) -> str:
        """Returns the language of this Literal, or an empty string if there is no language"""
        return tentris_sys.rdf4cpp_literal_lang(self._inner)

    def __str__(self):
        """Return the N-string representation of this Literal"""
        return tentris_sys.rdf4cpp_serialize(self._inner)

    def __repr__(self):
        return f"Literal._from_raw(tentris_sys.rdf4cpp_node({int(self._inner)}))"

    def __int__(self) -> int:
        """
        Returns internal ID of the Literal.
        IDs of Literals constructed via __init__() and Literals from TripleStores might not match.
        """
        return int(self._inner)

    def __hash__(self):
        return int(self)

    def __eq__(self, other: "Node"):
        """node comparison as defined by SPARQL"""
        return tentris_sys.rdf4cpp_term_cmp(self._inner, other._inner) == 0

    def __lt__(self, other: "Node"):
        """node comparison as defined by SPARQL"""
        return tentris_sys.rdf4cpp_term_cmp(self._inner, other._inner) < 0


@functools.total_ordering
class BNode:
    __slots__ = "_inner",

    @classmethod
    def _from_raw(cls, inner: tentris_sys.rdf4cpp_node):
        self = cls.__new__(cls)
        self._inner = inner
        return self

    def __init__(self, identifier: str):
        """Constructs a BNode with the given identifier"""
        self._inner = tentris_sys.rdf4cpp_make_bnode(identifier)

    def identifier(self) -> str:
        """Returns the identifier of this BNode"""
        return tentris_sys.rdf4cpp_bnode_identifier(self._inner)

    def __str__(self):
        """Returns the N-format representation of this BNode"""
        return tentris_sys.rdf4cpp_serialize(self._inner)

    def __repr__(self):
        return f"BNode._from_raw(tentris_sys.rdf4cpp_node({int(self._inner)}))"

    def __int__(self) -> int:
        """
        Returns internal ID of the BNode.
        IDs of BNodes constructed via __init__() and BNodes from TripleStores might not match.
        """
        return int(self._inner)

    def __hash__(self):
        return int(self)

    def __eq__(self, other: "Node"):
        """node comparison as defined by SPARQL"""
        return tentris_sys.rdf4cpp_term_cmp(self._inner, other._inner) == 0

    def __lt__(self, other: "Node"):
        """node comparison as defined by SPARQL"""
        return tentris_sys.rdf4cpp_term_cmp(self._inner, other._inner) < 0


@functools.total_ordering
class Variable:
    __slots__ = "_inner",

    @classmethod
    def _from_raw(cls, inner: tentris_sys.rdf4cpp_node):
        self = cls.__new__(cls)
        self._inner = inner
        return self

    def __init__(self, name: str):
        """Constructs a variable with the given name"""
        self._inner = tentris_sys.rdf4cpp_make_variable(name)

    def name(self) -> str:
        """Returns the name of this variable"""
        return tentris_sys.rdf4cpp_variable_name(self._inner)

    def __str__(self):
        """Returns the N-format representation of this Variable"""
        return tentris_sys.rdf4cpp_serialize(self._inner)

    def __repr__(self):
        return f"Variable._from_raw(tentris_sys.rdf4cpp_node({int(self._inner)}))"

    def __int__(self) -> int:
        """
        Returns internal ID of the Variable.
        IDs of Variables constructed via __init__() and Variables from TripleStores might not match.
        """
        return int(self._inner)

    def __hash__(self):
        return int(self)

    def __eq__(self, other: "Node"):
        """node comparison as defined by SPARQL"""
        return tentris_sys.rdf4cpp_term_cmp(self._inner, other._inner) == 0

    def __lt__(self, other: "Node"):
        """node comparison as defined by SPARQL"""
        return tentris_sys.rdf4cpp_term_cmp(self._inner, other._inner) < 0


Node = typing.Union[IRI, Literal, BNode, Variable]
Term = typing.Union[IRI, Literal, BNode]


def serialize_ntriples(subject: typing.Union[IRI, BNode], predicate: IRI, object: typing.Union[IRI, BNode, Literal]) -> str:
    return tentris_sys.rdf4cpp_serialize_ntriples(subject._inner, predicate._inner, object._inner)


def _id_to_rdf(id: int) -> typing.Optional[Node]:
    raw_node = tentris_sys.rdf4cpp_node(id)
    if tentris_sys.rdf4cpp_term_null(raw_node):
        return None

    if tentris_sys.rdf4cpp_is_literal(raw_node):
        return Literal._from_raw(raw_node)
    elif tentris_sys.rdf4cpp_is_iri(raw_node):
        return IRI._from_raw(raw_node)
    elif tentris_sys.rdf4cpp_is_bnode(raw_node):
        return BNode._from_raw(raw_node)
    else:
        return Variable._from_raw(raw_node)


class RDF:
    _NS = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    langString = IRI(_NS + "langString")


class XSD:
    _NS = "http://www.w3.org/2001/XMLSchema#"
    string = IRI(_NS + "string")
    boolean = IRI(_NS + "boolean")
    decimal = IRI(_NS + "decimal")
    double = IRI(_NS + "double")
    float = IRI(_NS + "float")
    integer = IRI(_NS + "integer")
    nonNegativeInteger = IRI(_NS + "nonNegativeInteger")
    positiveInteger = IRI(_NS + "positiveInteger")
    nonPositiveInteger = IRI(_NS + "nonPositiveInteger")
    negativeInteger = IRI(_NS + "negativeInteger")
    long = IRI(_NS + "long")
    int = IRI(_NS + "int")
    short = IRI(_NS + "short")
    byte = IRI(_NS + "byte")
    unsignedLong = IRI(_NS + "unsignedLong")
    unsignedInt = IRI(_NS + "unsignedInt")
    unsignedShort = IRI(_NS + "unsignedShort")
    unsignedByte = IRI(_NS + "unsignedByte")


class MetallManager:
    __slots__ = "_inner",

    def __init__(self, datastore_path: str, *, create_if_not_exists: bool = False):
        """
        Constructs a new metall manager for the given path.

        Warning: Metall managers need to be closed by either using `close()` or using a `with` block,
            otherwise the program might crash.

        :param datastore_path: The path to the metall datastore
        :param create_if_not_exists: Whether to create the metall datatstore if there is none at the given location
        """
        self._inner = None

        if create_if_not_exists:
            self._inner = tentris_sys.metall_create(datastore_path)
        else:
            self._inner = tentris_sys.metall_open(datastore_path)

    def close(self):
        """closes the metall manager"""
        if self._inner is not None:
            tentris_sys.metall_close(self._inner)
            self._inner = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def snapshot(self, dst_datastore_path: str):
        """
        Creates a snapshot of the datastore of this metall manager and places it at the given path

        :param dst_datastore_path: Where to create the snapshot
        """
        tentris_sys.metall_snapshot(self._inner, dst_datastore_path)

    @staticmethod
    def remove(path: str):
        """Removes the datastore at the given path"""
        tentris_sys.metall_remove(path)


class QueryType(enum.IntEnum):
    SELECT = tentris_sys.QT_SELECT
    ASK = tentris_sys.QT_ASK
    CONSTRUCT = tentris_sys.QT_CONSTRUCT
    DESCRIBE = tentris_sys.QT_DESCRIBE
    DELETE = tentris_sys.QT_DELETE
    INSERT = tentris_sys.QT_INSERT
    DELETE_AND_INSERT = tentris_sys.QT_DELETE_AND_INSERT
    DELETE_DATA = tentris_sys.QT_DELETE_DATA
    INSERT_DATA = tentris_sys.QT_INSERT_DATA


SELECTResult = typing.Tuple[typing.Mapping[Variable, Term], int]
"""
Tuple of solution mappings (projected variable -> bound value) and multiplicity.
"""

CONSTRUCTResult = typing.Tuple[Term, Term, Term]
"""
3-Tuples of terms forming an RDF graph.
Solutions are just a tuple of terms because CONSTRUCT queries do not project any variables.
"""

ASKResult = int
"""
Multiplicity of the result
"""


class SPARQLSolutionGenerator:
    __slots__ = "__inner", "__cur_sol", "__proj_vars", "__life_parent"

    @classmethod
    def _from_raw(cls, inner, parent):
        self = cls.__new__(cls)
        self.__inner = inner
        self.__cur_sol = tentris_sys.tentris_solution()
        self.__proj_vars = tentris_sys.tentris_solution_generator_get_projected_variables(self.__inner)
        self.__life_parent = parent
        return self

    def drop(self):
        if self.__inner is not None:
            tentris_sys.tentris_solution_generator_free(self.__inner)
            self.__inner = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.drop()

    def __iter__(self):
        return self

    def __next__(self) -> typing.Union[SELECTResult, CONSTRUCTResult, ASKResult]:
        """
        Returns the next solution.
        The return type is dependent on the query type being evaluated.
        See type hints for details on the return type.

        Warning: The results of this generator will only live as long as the generator is not drop()ed
        """
        tentris_sys.tentris_solution_generator_next(self.__inner, self.__cur_sol)

        if self.query_type == QueryType.ASK:
            return self.__cur_sol.count
        elif self.query_type == QueryType.CONSTRUCT:
            return (_id_to_rdf(self.__cur_sol.key[0]),
                    _id_to_rdf(self.__cur_sol.key[1]),
                    _id_to_rdf(self.__cur_sol.key[2]))
        else:
            return {var: _id_to_rdf(value) for var, value in
                    zip(self.projected_variables, self.__cur_sol.key)}, self.__cur_sol.count

    @property
    def projected_variables(self) -> typing.List[Variable]:
        """Returns the variables that this generator projects"""
        return [Variable._from_raw(var) for var in self.__proj_vars]

    @property
    def query_type(self) -> QueryType:
        """Returns the query type of this generator"""
        return QueryType(tentris_sys.tentris_solution_generator_get_query_type(self.__inner))


class HypertrieIterator:
    __slots__ = "__inner", "__dtype", "__life_parent"

    @classmethod
    def _from_raw(cls, inner, dtype, parent):
        self = cls.__new__(cls)
        self.__inner = inner
        self.__dtype = dtype
        self.__life_parent = parent
        return self

    def __del__(self):
        tentris_sys.hypertrie_iterator_free(self.__inner)

    def __next__(self) -> typing.Tuple[typing.List[int], typing.Union[bool, int, float]]:
        """Returns the next entry of this HypertrieIterator"""
        res = tentris_sys.hypertrie_iterator_next(self.__inner, self.__dtype)
        if res is None:
            raise StopIteration()

        return res[0], res[1]

    @property
    def dtype(self):
        """Returns the dtype of the hypertrie being iterated"""
        return self.__dtype


HypertrieKey = typing.Union[int, typing.Tuple[int, ...]]
HypertrieSliceKeyPart = typing.Union[slice, int]
HypertrieSliceKey = typing.Union[HypertrieSliceKeyPart, typing.Tuple[HypertrieSliceKeyPart, ...]]
HypertrieValue = typing.Union[bool, int, float]


class Hypertrie:
    __slots__ = "_inner", "__dtype", "__life_parent"

    @classmethod
    def _from_raw(cls, inner, dtype, parent) -> "Hypertrie":
        self = cls.__new__(cls)
        self._inner = inner
        self.__dtype = dtype
        self.__life_parent = parent
        return self

    def drop(self):
        """Drops this hypertrie"""
        if self._inner is not None:
            tentris_sys.hypertrie_free(self._inner)
            self._inner = None

    def __init__(self, dtype, depth):
        """
        Creates a new Hypertrie with the given dtype and depth

        :param dtype: datatype of the hypertrie
        :param depth: depth of the hypertrie
        """
        self._inner = tentris_sys.hypertrie_new_in_memory(dtype, depth)
        self.__dtype = dtype
        self.__life_parent = None

    def __del__(self):
        self.drop()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.drop()

    def __getitem__(self, key: HypertrieSliceKey) -> typing.Union["Hypertrie", HypertrieValue]:
        """
        Slices this hypertrie

        :param key: slice key
        :return: resulting slice
        :raises: exception if key length does not match depth of this Hypertrie
                or elements of the slice key cannot be used to slice this Hypertrie (valid elements are `:` and ints)
        """
        def translate_index(index):
            if type(index) is slice:
                if index.start is None and index.stop is None and index.step is None:
                    return None
                else:
                    raise ValueError("Ranged slice not supported")
            else:
                return index

        def is_capsule(o):
            t = type(o)
            return t.__module__ == 'builtins' and t.__name__ == 'PyCapsule'

        key = [translate_index(kp) for kp in key] \
            if hasattr(key, "__len__") and hasattr(key, "__getitem__") \
            else [translate_index(key)]

        s = tentris_sys.hypertrie_slice(self._inner, key, self.dtype)
        if is_capsule(s):
            return Hypertrie._from_raw(s, self.dtype, self)
        else:
            return s

    def __setitem__(self, key: HypertrieKey, value: HypertrieValue):
        """
        Sets an element in this hypertrie

        :param key: key to set value for
        :param value: value to set key to
        :return: old value
        """

        key = key if hasattr(key, "__len__") and hasattr(key, "__getitem__") else [key]
        tentris_sys.hypertrie_set(self._inner, key, self.dtype, value)

    def __iter__(self) -> HypertrieIterator:
        iter = tentris_sys.hypertrie_iterate(self._inner)
        return HypertrieIterator._from_raw(iter, self.dtype, self)

    def __len__(self):
        """Returns the number of elements in this hypertrie"""
        return tentris_sys.hypertrie_size(self._inner)

    @property
    def depth(self) -> int:
        """Returns the depth of this hypertrie"""
        return tentris_sys.hypertrie_depth(self._inner)

    @property
    def dtype(self):
        """Returns the datatype of this hypertrie"""
        return self.__dtype

    def clone(self) -> "Hypertrie":
        """
        Creates a copy-on-write clone of this hypertrie
        This is a O(1) operation.

        :raises: exception if the clone could not be created.
                This happens if self was obtained by TripleStore.get_hypertrie().
        """
        return Hypertrie._from_raw(tentris_sys.hypertrie_clone(self._inner), self.dtype, None)

    def convert(self, new_dtype) -> "Hypertrie":
        """
        Converts this hypertrie by copying its contents into a new hypertrie
        This is a O(len(self)) operation.

        :param new_dtype: new datatype of this hypertrie
        :return: the converted hypertrie
        """
        ret = Hypertrie(dtype=new_dtype, depth=self.depth)
        tentris_sys.hypertrie_copy_into(self._inner, ret._inner)
        return ret


class RDFFormat(enum.IntEnum):
    """Format of an RDF file"""
    TURTLE = tentris_sys.TRF_TURTLE
    NTRIPLES = tentris_sys.TRF_NTRIPLES


class TripleStore:
    __slots__ = "_inner", "__manager",

    def __init__(self, *, data: typing.Optional[str] = None, versions_limit: typing.Optional[int] = None,
                 manager: typing.Optional[MetallManager] = None, instance_name: str = "tentris-triplestore"):
        """
        Constructs a triplestore.

        Warning: TripleStore instances must be dropped by calling `self.drop()` or using a `with` block,
            otherwise the program might crash.

        :param data: optionally a path to an RDF data file to be loaded
        :param versions_limit: optionally, the maximum number of versions allowed to be simultaneously active
                (https://en.wikipedia.org/wiki/Multiversion_concurrency_control)
        :param manager: optionally a metall manager to persist this triplestore,
                if None is provided the triplestore will not be persisted
        :param instance_name: Name of the new triplestore instance inside the metall manager
        """
        if versions_limit is None:
            versions_limit = tentris_sys.TENTRIS_NO_VERSIONS_LIMIT

        self.__manager = manager

        if manager is None:
            self._inner = tentris_sys.tentris_triplestore_new_in_memory(versions_limit)
        else:
            self._inner = tentris_sys.tentris_triplestore_find_or_construct_persistent(manager._inner,
                                                                                       instance_name, versions_limit)

        if data is not None:
            self.load_rdf_data(data)

    def drop(self):
        """Drops this triplestore"""
        if self._inner is not None:
            tentris_sys.tentris_triplestore_free(self._inner)
            self._inner = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.drop()

    def load_rdf_data(self, path: str, *, format: RDFFormat = RDFFormat.TURTLE,
                      bulk_size: int = tentris_sys.TENTRIS_DEFAULT_LOAD_BULK_SIZE):
        """
        Load an rdf data file into this triplestore

        :param path: path to the turtle file
        :param bulk_size: the size of the bulks for insertion, lower bulk size decreases memory usage,
                higher bulk size increases performance
        :raises: an exception if the file could not be loaded
        """
        if bulk_size < 0 or bulk_size >= 2**32:
            raise RuntimeError("bulk_size must be in range of a 32bit integer")

        tentris_sys.tentris_triplestore_load_rdf_data(self._inner, path, int(format),
                                                      bulk_size)

    def eval_sparql_query(self, query: str, *, timeout_ms: typing.Optional[int] = None) -> SPARQLSolutionGenerator:
        """
        Returns a generator that evaluates a SPARQL (read) query.

        Warning: The returned generator must be dropped by calling `gen.drop()` or using a `with` block,
            otherwise the program might crash.

        :param query: the SPARQL query to evaluate
        :param timeout_ms: optionally, a timeout in milliseconds after which evaluation should be aborted
        :return: A generator that yields the solutions of the query
        """
        if timeout_ms is None:
            timeout_ms = tentris_sys.TENTRIS_NO_TIMEOUT

        gen = tentris_sys.tentris_triplestore_eval_query(self._inner, query, timeout_ms)
        return SPARQLSolutionGenerator._from_raw(gen, self)

    def eager_eval_sparql_query(self, query: str, *, timeout_ms: typing.Optional[int] = None) \
            -> typing.Union[ASKResult, typing.List[SELECTResult], typing.Set[CONSTRUCTResult]]:
        """
        Eagerly evaluates a SPARQL (read) query.

        :param query: the SPARQL query to evaluate
        :param timeout_ms: optionally, a timeout in milliseconds after which evaluation should be aborted
        :return: Fully materialized result of the SPARQL query
        """

        with self.eval_sparql_query(query, timeout_ms=timeout_ms) as gen:
            if gen.query_type == QueryType.ASK:
                ret = 0
                for multiplicity in gen:
                    ret += multiplicity

                return ret
            elif gen.query_type == QueryType.CONSTRUCT:
                ret = set()
                for solution in gen:
                    ret.add(solution)

                return ret
            else:
                ret = []
                for bindings, multiplicity in gen:
                    ret.append((bindings, multiplicity))

                return ret

    def eval_sparql_update(self, update: str, *, timeout_ms: typing.Optional[int] = None):
        """
        Evaluates a SPARQL update

        :param update: the SPARQL update query to evaluate
        :param timeout_ms: optionally, a timeout in milliseconds after which evaluation should be aborted.
                Note: this timeout only starts ticking after the transaction has started evaluating.
        """
        if timeout_ms is None:
            timeout_ms = tentris_sys.TENTRIS_NO_TIMEOUT

        tentris_sys.tentris_triplestore_eval_update(self._inner, update, timeout_ms)

    def hypertrie(self) -> Hypertrie:
        """
        Returns a view into the inner hypertrie of this triplestore.

        Warning: The returned hypertrie instance must be dropped by calling `hyp.drop()` or using a `with` block,
            otherwise the program might crash.

        Note:
            The keys of the hypertrie will be integer valued and the individual key parts
            represent the IDs of the RDF nodes from this triplestore.
            To convert from ID to RDF node use TripleStore.id_to_rdf.

        :return: The underlying hypertrie of this triplestore
        """
        return Hypertrie._from_raw(tentris_sys.tentris_triplestore_get_hypertrie(self._inner), numpy.bool_, self)

    def try_get_resource(self, term: typing.Union[int, Node]) -> typing.Optional[Node]:
        """
        Converts the given RDF node (or node ID) into the same node in this triplestore.
        If the given node does not exist in this triplestore returns None.

        :param term: RDF node to convert
        :return: if present the same RDF node but in this triplestore, otherwise None
        """

        raw = tentris_sys.rdf4cpp_node(term) if type(term) is int else term._inner
        resource = tentris_sys.tentris_triplestore_try_get_resource(self._inner, raw)
        return _id_to_rdf(resource)

    @property
    def manager(self) -> typing.Optional[MetallManager]:
        """Returns the metall manager (if there is one) for this Triplestore"""
        return self.__manager


class EinsumSumSolutionGenerator:
    __slots__ = "__inner", "__dtype", "__cur_sol", "__life_operands"

    @classmethod
    def _from_raw(cls, inner, life_operands: typing.List[Hypertrie]):
        self = cls.__new__(cls)
        self.__inner = inner
        self.__dtype = life_operands[0].dtype
        self.__cur_sol = tentris_sys.hypertrie_einsumsum_solution()
        self.__life_operands = life_operands
        return self

    def drop(self):
        if self.__inner is not None:
            tentris_sys.hypertrie_einsumsum_solution_generator_free(self.__inner)
            self.__inner = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.drop()

    def __iter__(self):
        return self

    def __next__(self) -> typing.Tuple[typing.List[int], typing.Union[bool, int, float]]:
        """Returns the next solution of this einsumsum generator"""
        return tentris_sys.hypertrie_einsumsum_solution_generator_next(self.__inner, self.__dtype, self.__cur_sol)

    @property
    def result_depth(self) -> int:
        """Returns the depth of the yielded solutions"""
        return tentris_sys.hypertrie_einsumsum_solution_generator_result_depth(self.__inner)

    @property
    def result_dtype(self):
        """Returns the dtype of the yielded solutions"""
        return self.__dtype

    def try_extend_hypertrie(self, hyp: Hypertrie):
        """
        Combines all entries this generator generates and inserts then into the given hypertrie.
        This only works if `self.result_dtype == hyp.dtype and self.result_depth == hyp.depth`.
        If these preconditions are not met, the function will raise an exception.
        """
        tentris_sys.hypertrie_consume_einsumsum_solution_generator(self.__inner, hyp._inner)


def einsumsum(subscript: str, operands: typing.List[Hypertrie]) -> EinsumSumSolutionGenerator:
    """
    Evaluate a sum-extended einstein summation on the given hypertries

    Warning: The generator must be closed by using `gen.drop()` or by using a `with` block,
        otherwise the program might crash.

    Warning:
        The generator may return multiple entries with the same key.
        The values of entries with the same key need to be added (non-bool-valued) / or-ed (bool-valued) to get
        the final result for that key.
        If you need to create a hypertrie anyways, consider using EinsumSumSolutionGenerator.try_extend_hypertrie

    :param subscript: string encoding the subscript
    :param operands: the operands that are subscripted with subscript
    :raises: an exception if subscript is malformed or isn't compatible with operands
    :return: generator yielding the results of the einstein summation
    """
    gen = tentris_sys.hypertrie_einsumsum(subscript, [h._inner for h in operands])
    return EinsumSumSolutionGenerator._from_raw(gen, operands)


if __name__ == "__main__":
    def run_tests():
        import logging
        import numpy as np
        import random

        logging.basicConfig(level=logging.INFO)

        assert XSD.string.identifier() == "http://www.w3.org/2001/XMLSchema#string"
        assert XSD.integer.identifier() == "http://www.w3.org/2001/XMLSchema#integer"

        i1 = IRI("http://url.com#xyz")
        assert i1.identifier() == "http://url.com#xyz"

        b1 = BNode("blank")
        assert b1.identifier() == "blank"

        v1 = Variable("var")
        assert v1.name() == "var"

        l1 = Literal("Hello World")
        assert l1.lexical_form() == "Hello World"
        assert l1.language() == ""
        assert l1.datatype() == XSD.string

        l2 = Literal("5", datatype=XSD.integer)
        assert l2.lexical_form() == "5"
        assert l2.language() == ""
        assert l2.datatype() == XSD.integer

        l3 = Literal("Spherical Cow", language="en")
        assert l3.lexical_form() == "Spherical Cow"
        assert l3.language() == "en"
        assert l3.datatype() == RDF.langString

        try:
            Literal("xyz", language="en", datatype=XSD.integer)
            assert False
        except ValueError:
            pass

        try:
            Literal("xyz", datatype=RDF.langString)
            assert False
        except ValueError:
            pass

        h = Hypertrie(dtype=np.int64, depth=3)
        h[1, 2, 3] = 20
        h[2, 3, 4] = 10
        assert len(h) == 2
        assert h[1, 2, 3] == 20
        assert h[2, 3, 4] == 10
        assert h.dtype == np.int64
        assert h.depth == 3
        assert sorted([x for x in h]) == [([1, 2, 3], 20), ([2, 3, 4], 10)]

        hclone = h.clone()
        assert len(hclone) == 2
        assert hclone[1, 2, 3] == 20
        assert hclone[2, 3, 4] == 10
        assert hclone.dtype == np.int64
        assert hclone.depth == 3
        assert sorted([x for x in hclone]) == [([1, 2, 3], 20), ([2, 3, 4], 10)]

        hclone[3, 4, 5] = 30
        assert len(hclone) == 3
        assert len(h) == 2
        assert hclone[3, 4, 5] == 30
        assert h[3, 4, 5] == 0

        slice = h[1, 2, :]
        assert slice.depth == 1
        assert slice[3] == 20
        assert slice.dtype == np.int64
        assert sorted([x for x in slice]) == [([3], 20)]

        slice = h[:, 2, 3]
        assert slice.depth == 1
        assert slice[1] == 20
        assert slice.dtype == np.int64
        assert sorted([x for x in slice]) == [([1], 20)]

        try:
            slice = h[1:2, 2, 3]
            assert False
        except:
            pass

        try:
            slice = h[1, 2, 3, 4, 5, 6]
            assert False
        except:
            pass

        try:
            slice = h[1, 2, 3, 4]
            assert False
        except:
            pass

        try:
            h[1, 2, 3, 4, 5, 6] = 5
            assert False
        except:
            pass

        try:
            h[1, 2, 3, 4] = 5
            assert False
        except:
            pass

        hb = Hypertrie(depth=3, dtype=np.bool_)
        hb[1, 2, 3] = True
        assert len(hb) == 1
        assert hb.dtype == np.bool_
        assert hb.depth == 3
        assert [x for x in hb] == [([1, 2, 3], True)]

        with einsumsum("abc,def->ad", [h, h]) as e:
            assert sorted([x for x in e]) == [([1, 1], 400), ([1, 2], 200), ([2, 1], 200), ([2, 2], 100)]

        hf = h.convert(np.float_)
        with einsumsum("abc,def->ad", [hf, hf]) as e:
            hyp = Hypertrie(depth=e.result_depth, dtype=e.result_dtype)
            e.try_extend_hypertrie(hyp)
            assert sorted([x for x in hyp]) == [([1, 1], 400.0), ([1, 2], 200.0), ([2, 1], 200.0), ([2, 2], 100.0)]

        with TripleStore() as ts:
            with ts.eval_sparql_query("SELECT (COUNT(*) as ?ntriples) WHERE { ?s ?p ?o }") as q:
                assert q.projected_variables == [Variable("ntriples")]

                solutions = [x for x in q]
                assert solutions == [({Variable("ntriples"): Literal("0", datatype=XSD.integer)}, 1)]

        datastore_path = f"/tmp/tentris-py-test-datastore{random.randint(0, 2**64)}"
        with MetallManager(datastore_path, create_if_not_exists=True) as manager:
            # Create triplestore
            with TripleStore(manager=manager) as pts:
                subj_node = IRI("http://hello.com#s")
                pred_node = IRI("http://hello.com#p")
                obj_node = Literal("Hello")

                pts.eval_sparql_update(f"INSERT DATA {{ {subj_node} {pred_node} {obj_node} }}")

                assert subj_node.identifier() == "http://hello.com#s"
                assert pred_node.identifier() == "http://hello.com#p"
                assert obj_node.lexical_form() == "Hello"
                assert obj_node.language() == ""
                assert obj_node.datatype() == XSD.string

                subj = pts.try_get_resource(subj_node)
                pred = pts.try_get_resource(pred_node)
                obj = pts.try_get_resource(obj_node)

                assert subj is not None
                assert pred is not None
                assert obj is not None
                assert int(subj_node) != int(subj)
                assert int(pred_node) != int(pred)
                assert int(obj_node) != int(obj)

                assert subj.identifier() == subj_node.identifier()
                assert pred.identifier() == pred_node.identifier()
                assert obj.lexical_form() == obj_node.lexical_form()

                assert subj == subj_node
                assert pred == pred_node
                assert obj == obj_node

            # Open created triplestore
            with TripleStore(manager=manager) as pts:
                with pts.hypertrie() as hyp:
                    assert hyp.dtype == np.bool_
                    assert hyp.depth == 3
                    assert len(hyp) == 1
                    assert hyp[int(subj), int(pred), int(obj)]

                    try:
                        hyp[1, 2, 3] = True
                        assert False  # cannot write to read-only hypertrie
                    except RuntimeError:
                        pass

                    try:
                        clone = hyp.clone()
                        assert False
                    except RuntimeError:
                        pass

                    conv = hyp.convert(np.int64)
                    assert len(conv) == 1
                    assert conv.dtype == np.int64
                    assert conv.depth == 3
                    assert conv[int(subj), int(pred), int(obj)] == 1

                    slice = conv[int(subj), int(pred), :]
                    for [obji], value in slice:
                        assert pts.try_get_resource(obji) == obj

                    with einsumsum("abc,spo->aspo", [h, conv]) as e:
                        lst = [x for x in e]
                        assert len(lst) == 2
                        assert sorted(lst) == [([1, int(subj), int(pred), int(obj)], 20),
                                               ([2, int(subj), int(pred), int(obj)], 10)]

                from io import BytesIO
                from urllib.request import urlopen
                from zipfile import ZipFile

                swdf_link = "https://files.dice-research.org/datasets/ISWC2020_Tentris/swdf.zip"
                ZipFile(BytesIO(urlopen(swdf_link).read())).extractall("/tmp")
                pts.load_rdf_data("/tmp/swdf.nt")

                with pts.eval_sparql_query("SELECT (COUNT(*) as ?ntriples) WHERE { ?s ?p ?o }") as q:
                    assert q.projected_variables == [Variable("ntriples")]
                    assert q.query_type == QueryType.SELECT

                    print("\nSELECT Results:")
                    for bindings, multiplicity in q:
                        assert multiplicity == 1
                        assert len(bindings) == 1
                        size = int(bindings[Variable("ntriples")].lexical_form())
                        assert size > 300000
                        print(", ".join([f"{var}: {val}" for var, val in bindings.items()]), multiplicity)

                select_res = pts.eager_eval_sparql_query("SELECT (COUNT(*) as ?ntriples) WHERE { ?s ?p ?o }")
                assert len(select_res) == 1
                assert select_res[0][0][Variable("ntriples")] > Literal("300000", datatype=XSD.long)

                with pts.eval_sparql_query("CONSTRUCT { ?s ?p ?o } WHERE { ?s ?p ?o } LIMIT 10") as q:
                    assert q.projected_variables == []
                    assert q.query_type == QueryType.CONSTRUCT

                    print("\nCONSTRUCT Results:")
                    for solution in q:
                        assert len(solution) == 3
                        print(serialize_ntriples(solution[0], solution[1], solution[2]))

                construct_res = pts.eager_eval_sparql_query("CONSTRUCT { ?s ?p ?o } WHERE { ?s ?p ?o } LIMIT 10")
                assert len(construct_res) == 10
                assert len(next(iter(construct_res))) == 3

                with pts.eval_sparql_query("ASK WHERE { ?s <http://xmlns.com/foaf/0.1/maker> ?o }") as q:
                    assert q.projected_variables == []
                    assert q.query_type == QueryType.ASK

                    print("\nASK Results:")
                    for multiplicity in q:
                        assert multiplicity > 0
                        print(multiplicity)

                multiplicity = pts.eager_eval_sparql_query("ASK WHERE { ?s <http://xmlns.com/foaf/0.1/maker> ?o }")
                assert multiplicity > 0

                try:
                    with pts.eval_sparql_query("SELECT AAAA"):
                        pass
                    assert False
                except RuntimeError as e:
                    assert "Parse Error" in str(e)

        MetallManager.remove(datastore_path)

    run_tests()
